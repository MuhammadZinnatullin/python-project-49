[![Maintainability](https://api.codeclimate.com/v1/badges/9240e845c98c8612d202/maintainability)](https://codeclimate.com/github/MuhammadZinnatullin/python-project-49/maintainability)



# Название проекта

Проект: Игры разума.

## Установка

python3 -m pip install --user dist/*.whl

## Использование

https://asciinema.org/a/VJcVMH4s3331uBMcOrnfZdz14
https://asciinema.org/a/fs3qYhkGQVERwulIpQsD0Iyro
https://asciinema.org/a/rpRhLeXMmRPQuOGxm0AU28oBu
https://asciinema.org/a/edBjA8wv6s6rrCokcmgIWOl4G
https://asciinema.org/a/VDBi0dkyYBLvnImAW618hbKQ0

## Контакты

Зиннатуллин Мухаммад
zinnatullin.muhammad@gmail.com
